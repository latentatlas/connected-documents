Recorded fictional example; no new model call.
These are the accepted texts, which may include the separately disclosed assistant corrections.
Assistant QA is not independent human review. No human productivity benefit is measured.
